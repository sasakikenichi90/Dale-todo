package com.dale.todo;
public class ExplicitPlanTest {
 static int n=0; static void check(boolean b){if(!b)throw new AssertionError("case "+(n+1));n++;}
 public static void main(String[] args)throws Exception{
 var a=ExplicitPlan.parse("今天写论文很重要，明天开会，每周三跑步，下周五交报告");check(a.size()==4);check(a.get(0).text.equals("写论文")&&a.get(0).priority==1);check(a.get(1).date.equals("明天"));check(a.get(2).repeat.equals("每周三"));check(a.get(3).date.equals("下周五"));
 check(ExplicitPlan.resolve("下周五","2026-11-18").equals("2026-11-27"));check(ExplicitPlan.resolve("每周三","2026-11-19").equals("2026-11-25"));check(ExplicitPlan.resolve("每周三","2026-11-18").equals("2026-11-18"));check(ExplicitPlan.resolve("明天","2026-12-31").equals("2027-01-01"));check(ExplicitPlan.resolve("下周五","2026-12-31").equals("2027-01-08"));check(ExplicitPlan.resolve("后天","2028-02-28").equals("2028-03-01"));
 check(ExplicitPlan.parse("明天下午三点开会").get(0).time.equals("15:00"));check(ExplicitPlan.parse("今天晚上八点半跑步").get(0).time.equals("20:30"));check(ExplicitPlan.parse("今天买菜，这个很重要").get(0).priority==1);check(ExplicitPlan.parse("今天买菜").get(0).time.isEmpty());check(ExplicitPlan.parse("今天三点")==null);check(ExplicitPlan.parse("明天开会，取消开会")==null);check(ExplicitPlan.parse("今天买菜然后跑步")==null);check(ExplicitPlan.parse("明天开会不重要")==null);check(ExplicitPlan.parse("今天下午买菜")==null);check(ExplicitPlan.parse("今天")==null);check(ExplicitPlan.parse("下周星期五")==null);System.out.println(n+" checks passed");}
}
