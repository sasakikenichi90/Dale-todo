大乐 · 每日计划 Android 原生工程（Java）
Android Studio 打开本目录，安装 Android SDK 35 和 JDK 17，等待 Gradle 同步，选择 Build > Build APK(s)。
调试 APK 通常位于 app/build/outputs/apk/debug/app-debug.apk。
文字、语音转文字（系统识别服务）、相册照片附件、日期归档、完成进度、编辑删除、次日复制。
本地 SharedPreferences 和应用私有照片目录保存，不需要账号。卸载可能清除数据。语音服务可能需要联网。
照片暂不支持 OCR；不含拍照入口、每日总结、备份导出。未编译及真机测试。
