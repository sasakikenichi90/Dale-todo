package com.dale.todo;
/** Unwrap only complete, explicitly fenced JSON. Never salvage partial tasks. */
final class AiJsonEnvelope {
 static String unwrap(String raw) {
  if(raw==null) throw new IllegalArgumentException("AI没有返回内容");
  String s=raw.trim(); if(s.startsWith("\uFEFF"))s=s.substring(1).trim();
  if(s.startsWith("```")) {
   int line=s.indexOf('\n');
   if(line<0 || !s.substring(3,line).trim().matches("(?i)(json)?") || !s.endsWith("```"))throw new IllegalArgumentException("AI返回格式不完整，请重试");
   s=s.substring(line+1,s.length()-3).trim();
  }
  if(!s.startsWith("[") || !s.endsWith("]"))throw new IllegalArgumentException("AI未返回完整任务列表，请重试");
  return s;
 }
}
