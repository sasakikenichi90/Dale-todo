package com.dale.todo;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;
import android.provider.CalendarContract.Calendars;
import android.provider.CalendarContract.Events;
import org.json.*;
import java.util.*;
import java.text.*;

/** Explicit export only, to an app-owned local calendar. Never edits unrelated events. */
final class CalendarBridge {
 static long calendar(Context c) throws Exception {
  String account=c.getPackageName(); ContentResolver r=c.getContentResolver();
  try(Cursor q=r.query(Calendars.CONTENT_URI,new String[]{Calendars._ID},Calendars.ACCOUNT_NAME+"=? AND "+Calendars.ACCOUNT_TYPE+"=? AND "+Calendars.NAME+"=?",new String[]{account,CalendarContract.ACCOUNT_TYPE_LOCAL,account},null)){if(q!=null&&q.moveToFirst())return q.getLong(0);}
  ContentValues v=new ContentValues();v.put(Calendars.ACCOUNT_NAME,account);v.put(Calendars.ACCOUNT_TYPE,CalendarContract.ACCOUNT_TYPE_LOCAL);v.put(Calendars.NAME,account);v.put(Calendars.CALENDAR_DISPLAY_NAME,c.getApplicationInfo().loadLabel(c.getPackageManager()).toString());v.put(Calendars.CALENDAR_COLOR,0xff5279b8);v.put(Calendars.CALENDAR_ACCESS_LEVEL,Calendars.CAL_ACCESS_OWNER);v.put(Calendars.OWNER_ACCOUNT,account);v.put(Calendars.VISIBLE,1);v.put(Calendars.SYNC_EVENTS,1);v.put(Calendars.CALENDAR_TIME_ZONE,TimeZone.getDefault().getID());
  Uri uri=Calendars.CONTENT_URI.buildUpon().appendQueryParameter(CalendarContract.CALLER_IS_SYNCADAPTER,"true").appendQueryParameter(Calendars.ACCOUNT_NAME,account).appendQueryParameter(Calendars.ACCOUNT_TYPE,CalendarContract.ACCOUNT_TYPE_LOCAL).build();Uri created=r.insert(uri,v);if(created==null)throw new IllegalStateException("无法创建专属日历");return ContentUris.parseId(created);
 }
 static int sync(Context c,String day,JSONArray tasks,int mode) throws Exception {
  long cal=calendar(c); ContentResolver r=c.getContentResolver(); String prefix="dailyplan:"+c.getPackageName()+":";
  Map<String,JSONObject> local=new HashMap<>(); for(int i=0;i<tasks.length();i++){JSONObject o=tasks.optJSONObject(i);if(o==null||o.optBoolean("archived"))continue;String key=o.optString("calendarKey");if(key.isEmpty()){key=prefix+UUID.randomUUID();o.put("calendarKey",key);}local.put(key,o);}
  SimpleDateFormat utc=new SimpleDateFormat("yyyy-MM-dd",Locale.ROOT);utc.setTimeZone(TimeZone.getTimeZone("UTC"));SimpleDateFormat date=new SimpleDateFormat("yyyy-MM-dd",Locale.ROOT), clock=new SimpleDateFormat("HH:mm",Locale.ROOT); Map<String,Long> ids=new HashMap<>(); int count=0;
  try(Cursor q=r.query(Events.CONTENT_URI,new String[]{Events._ID,Events.DESCRIPTION,Events.TITLE,Events.DTSTART,Events.ALL_DAY},Events.CALENDAR_ID+"=? AND "+Events.DELETED+"=0",new String[]{Long.toString(cal)},null)){
   if(q==null)throw new IllegalStateException("无法读取日历");while(q.moveToNext()){long id=q.getLong(0);String key=q.getString(1);boolean all=q.getInt(4)!=0;Date start=new Date(q.getLong(3));if(!(all?utc:date).format(start).equals(day))continue;if(key==null||!key.startsWith(prefix))key=prefix+"event:"+id;ids.put(key,id);if(mode==0)continue;JSONObject o=local.get(key);String title=q.getString(2);if(title==null||title.trim().isEmpty())continue;boolean done=title.startsWith("✓ ");if(done)title=title.substring(2);boolean important=title.startsWith("★ ");if(important)title=title.substring(2);String time=all?"":clock.format(start);String signature=title+"\n"+time+"\n"+done+"\n"+important;
   if(o==null){o=new JSONObject();o.put("calendarKey",key);o.put("text",title);o.put("time",time);o.put("done",done);o.put("priority",important?1:0);tasks.put(o);local.put(key,o);count++;}else if(mode==1||(!signature.equals(o.optString("calendarBaseline"))&&fingerprint(o).equals(o.optString("calendarBaseline")))){o.put("text",title);o.put("time",time);o.put("done",done);o.put("priority",important?1:0);count++;}o.put("calendarBaseline",signature);
  }}
  if(mode==1)return count;
  for(Map.Entry<String,JSONObject> e:local.entrySet()){JSONObject o=e.getValue();String key=e.getKey();String time=o.optString("time");boolean all=!time.matches("(?:[01]\\d|2[0-3]):[0-5]\\d");SimpleDateFormat f=new SimpleDateFormat(all?"yyyy-MM-dd":"yyyy-MM-dd HH:mm",Locale.ROOT);f.setLenient(false);if(all)f.setTimeZone(TimeZone.getTimeZone("UTC"));long start=f.parse(all?day:day+" "+time).getTime();ContentValues v=new ContentValues();v.put(Events.CALENDAR_ID,cal);v.put(Events.TITLE,(o.optBoolean("done")?"✓ ":"")+(o.optInt("priority")==1?"★ ":"")+o.optString("text"));v.put(Events.DTSTART,start);v.put(Events.DTEND,start+(all?86400000L:3600000L));v.put(Events.ALL_DAY,all?1:0);v.put(Events.EVENT_TIMEZONE,all?"UTC":TimeZone.getDefault().getID());Long id=ids.get(key);if(id==null){v.put(Events.DESCRIPTION,key);Uri result=r.insert(Events.CONTENT_URI,v);if(result==null)throw new IllegalStateException("写入失败");}else if(r.update(ContentUris.withAppendedId(Events.CONTENT_URI,id),v,null,null)!=1)throw new IllegalStateException("更新失败");o.put("calendarBaseline",fingerprint(o));count++;}return count;
 }
 static String fingerprint(JSONObject o){return o.optString("text")+"\n"+o.optString("time")+"\n"+o.optBoolean("done")+"\n"+(o.optInt("priority")==1);}
}
