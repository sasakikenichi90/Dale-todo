package com.dale.todo;
import org.json.JSONObject;
final class CategoryColors {
 static final int[] PALETTE={0xff42699d,0xff8563a5,0xff527747,0xff986020,0xffa34b76,0xff656963};
 static int index(String n){switch(n){case "科研工作":return 0;case "学习成长":return 1;case "生活日常":return 2;case "健康运动":return 3;case "约会":return 4;default:return 5;}}
 static int color(JSONObject o){return o.optInt("categoryColor",PALETTE[index(o.optString("category"))]);}
 static int background(JSONObject o){int c=color(o);return 0xff000000|((255*85+((c>>16)&255)*15)/100<<16)|((255*85+((c>>8)&255)*15)/100<<8)|((255*85+(c&255)*15)/100);}
}
