package com.dale.todo;
final class RewardRotation {
 static final int[] IMAGES={R.drawable.reward_day_0,R.drawable.reward_day_1,R.drawable.reward_day_2,R.drawable.reward_day_3,R.drawable.reward_day_4,R.drawable.reward_day_5,R.drawable.reward_day_6,R.drawable.reward_day_7,R.drawable.reward_day_8};
 static final String[] NOTES={"今天的每一步都算数。愿你一路遇见属于自己的好风景。","愿你的心像天空一样辽阔，烦恼轻一点，快乐多一点。","忙碌过后，记得给自己留一点自由和温柔。","把今天的辛苦交给夕阳，明天又是新的好日子。","天气再冷，也愿你心里一直有暖意。","愿每一次出发都有惊喜，每一次归来都有安心。","认真生活的你，值得拥有属于自己的慢时光。","今天辛苦啦，吃点喜欢的东西，好好休息。","愿你每天都有小小的惊喜，快乐常伴身边。"};
 static int index(String day){try{java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US);f.setLenient(false);f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));long n=f.parse(day).getTime()/86400000L;return (int)((n%9+9)%9);}catch(Exception e){return 0;}}
}
