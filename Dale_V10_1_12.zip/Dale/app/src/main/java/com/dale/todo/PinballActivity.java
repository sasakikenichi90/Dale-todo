package com.dale.todo;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.widget.*;
import android.graphics.Color;
public class PinballActivity extends Activity {
 private WebView web;
 @Override public void onCreate(Bundle state){super.onCreate(state);
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(0xff141a18);
  Button back=new Button(this);back.setText("‹ 返回大乐每日计划");back.setAllCaps(false);back.setOnClickListener(v->finish());root.addView(back);
  web=new WebView(this);web.setBackgroundColor(0xff141a18);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setBlockNetworkLoads(true);
  web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,String url){return true;} @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest req){return true;}});
  root.addView(web,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);web.loadUrl("file:///android_asset/pinball.html");
 }
 @Override protected void onPause(){if(web!=null){web.evaluateJavascript("window.pinballPause && window.pinballPause()",null);web.onPause();}super.onPause();}
 @Override protected void onResume(){super.onResume();if(web!=null)web.onResume();}
 @Override protected void onDestroy(){if(web!=null){((android.view.ViewGroup)web.getParent()).removeView(web);web.destroy();web=null;}super.onDestroy();}
}
