package com.dale.todo;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
final class LocalAI {
 static final String URL="https://huggingface.co/QuantFactory/Qwen3-0.6B-GGUF/resolve/main/Qwen3-0.6B.Q4_K_M.gguf";
 static final String SHA="7af3fdf842f87b24672f8a7f1dd50404043f0bfb71093ff91c31d2b49df4631d";
 static native byte[] infer(String path,byte[] prompt);
 static synchronized void download(File target)throws Exception{if(target.isFile())return;File part=new File(target.getPath()+".part");HttpURLConnection c=(HttpURLConnection)new URL(URL).openConnection();c.setConnectTimeout(20000);c.setReadTimeout(30000);try{if(c.getResponseCode()!=200)throw new IOException("下载失败");MessageDigest md=MessageDigest.getInstance("SHA-256");try(InputStream in=c.getInputStream();OutputStream out=new FileOutputStream(part)){byte[] b=new byte[65536];int n;long total=0;while((n=in.read(b))!=-1){total+=n;if(total>500000000L)throw new IOException("模型超过限制");md.update(b,0,n);out.write(b,0,n);}}StringBuilder hash=new StringBuilder();for(byte b:md.digest())hash.append(String.format(java.util.Locale.US,"%02x",b&255));if(!SHA.equals(hash.toString()))throw new IOException("模型校验失败");if(!part.renameTo(target))throw new IOException("模型保存失败");}finally{c.disconnect();part.delete();}}
 static String organize(File model,String input)throws Exception{System.loadLibrary("daleai");String p="<|im_start|>system\n你是待办整理助手。仅输出待办清单，每行一项，不要编号，不要解释。保留原文中的日期、重要程度、循环频率和持续时间，不添加任何新任务。<|im_end|>\n<|im_start|>user\n"+input+" /no_think<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n";byte[] r=infer(model.getAbsolutePath(),p.getBytes(StandardCharsets.UTF_8));if(r==null)throw new IOException("推理失败");String s=new String(r,StandardCharsets.UTF_8).trim();if(s.isEmpty()||s.contains("<think>"))throw new IOException("结果无效");return s;}
}
