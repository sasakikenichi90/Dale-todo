#include <jni.h>
#include <llama.h>
#include <string>
#include <vector>
#include <memory>
#include <mutex>
#include <chrono>
extern "C" JNIEXPORT jbyteArray JNICALL Java_com_dale_todo_LocalAI_infer(JNIEnv* e,jclass,jstring path,jbyteArray prompt,jint threads,jobject cancelled){
 static std::mutex mutex; std::lock_guard<std::mutex> lock(mutex);
 static bool init=(llama_backend_init(),true); (void)init;
 const char* p=e->GetStringUTFChars(path,nullptr); if(!p)return nullptr;
 auto mp=llama_model_default_params(); mp.n_gpu_layers=0;
 auto raw=llama_model_load_from_file(p,mp); e->ReleaseStringUTFChars(path,p);
 std::unique_ptr<llama_model,decltype(&llama_model_free)> model(raw,llama_model_free); if(!model)return nullptr;
 auto cp=llama_context_default_params();cp.n_ctx=2048;cp.n_batch=2048;cp.n_threads=threads;cp.n_threads_batch=threads;
 std::unique_ptr<llama_context,decltype(&llama_free)> ctx(llama_init_from_model(model.get(),cp),llama_free);if(!ctx)return nullptr;
 const auto* vocab=llama_model_get_vocab(model.get()); int len=e->GetArrayLength(prompt);std::string in(len,'\0');e->GetByteArrayRegion(prompt,0,len,reinterpret_cast<jbyte*>(in.data()));
 std::vector<llama_token> tok(1600);int n=llama_tokenize(vocab,in.data(),len,tok.data(),tok.size(),false,true);if(n<=0||n>1500)return nullptr;tok.resize(n);
 if(llama_decode(ctx.get(),llama_batch_get_one(tok.data(),n))!=0)return nullptr;
 std::unique_ptr<llama_sampler,decltype(&llama_sampler_free)> sampler(llama_sampler_init_greedy(),llama_sampler_free);std::string out;
 auto start=std::chrono::steady_clock::now(); auto cls=e->GetObjectClass(cancelled); auto get=e->GetMethodID(cls,"get","()Z"); if(!get)return nullptr; bool complete=false;
 for(int i=0;i<512;i++){if(e->CallBooleanMethod(cancelled,get)||std::chrono::steady_clock::now()-start>std::chrono::seconds(120))return nullptr;auto t=llama_sampler_sample(sampler.get(),ctx.get(),-1);if(llama_vocab_is_eog(vocab,t)){complete=true;break;}char buf[256];int k=llama_token_to_piece(vocab,t,buf,sizeof(buf),0,false);if(k<0)return nullptr;out.append(buf,k);if(llama_decode(ctx.get(),llama_batch_get_one(&t,1))!=0)return nullptr;}
 if(!complete)return nullptr;
 auto result=e->NewByteArray(out.size());if(result)e->SetByteArrayRegion(result,0,out.size(),reinterpret_cast<const jbyte*>(out.data()));return result;
}
