package com.dale.todo;
import org.json.*;
import java.util.regex.*;
final class SmartDraft {
 static JSONArray parse(String input,String day){JSONArray out=new JSONArray();for(String line:input.split("[\\n；;]+")){String t=line.trim().replaceFirst("^\\s*(?:[-•]|\\d+[.、)])\\s*", "");if(t.isEmpty())continue;try{JSONObject o=new JSONObject();o.put("text",t);o.put("priority",t.contains("重要")&&!t.contains("不重要")?1:0);int mode=0,n=1;Matcher m=Pattern.compile("每(?:隔)?([0-9]{1,4})(天|个月)").matcher(t);if(m.find()){n=Math.max(1,Integer.parseInt(m.group(1)));mode=m.group(2).equals("天")?3:4;}else if(t.contains("工作日"))mode=1;else if(t.contains("周末")||t.contains("休息日"))mode=2;else if(t.contains("每天"))mode=3;o.put("mode",mode);o.put("interval",n);o.put("start",day);String cat=t.matches(".*(运动|健身|跑步).*" )?"健康运动":t.matches(".*(论文|实验|汇报|报告).*" )?"科研工作":t.matches(".*(学习|阅读|文献).*" )?"学习成长":"其他事项";o.put("category",cat);out.put(o);if(out.length()>=50)break;}catch(JSONException ignored){}}return out;}
}
